package com.example.mobile_mini_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AdminShowcarAll : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_showcar_all)
    }
}